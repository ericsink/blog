
/*
 * Copyright 2007 Eric Sink
 * 
 * You may use this code under the terms of any of the
 * following licenses, your choice:
 * 
 * 1)  The GNU General Public License, Version 2
 *      http://www.opensource.org/licenses/gpl-license.php
 * 
 * 2)  The Apache License, Version 2.0
 *      http://www.opensource.org/licenses/apache2.0.php
 * 
 * 3)  The MIT License
 *      http://www.opensource.org/licenses/mit-license.php
 *
 * I am publishing this code on my blog as sample
 * code.  I am not intending to maintain this as a 
 * regular ongoing open source project or
 * anything like that.  I'm not looking for contributors
 * or hosting on sourceforge or anything like that.
 * 
 * Nonetheless, I hate it when I see an article with
 * sample code and it's not clear if I am allowed to
 * use the code or not.  The ambiguity is annoying.
 * So I am making this code available under your 
 * choice of open source licenses as described above.  
 * Informally and in a nutshell, you can use this code 
 * for any purpose as long as I am not liable for anything 
 * that goes wrong.  For a more tedious and formal 
 * explanation, pick one of the licenses above and use it.
 * 
 */

#if DEBUG

using System;
using System.Collections.Generic;
using System.Threading;
using System.Diagnostics;

using NUnit.Framework;

namespace PokerLib
{
	[TestFixture]
	public class tests
	{
        [Test]
        public void test_ValueHand_ints()
        {          
            Assert.AreEqual(HandValue.StraightFlush, Misc.GetHandValue(new int[] {7,6,5,4,3}));
            Assert.AreEqual(HandValue.Flush, Misc.GetHandValue(new int[] { 1,3,5,7,9 }));
            Assert.AreEqual(HandValue.Flush, Misc.GetHandValue(new int[] { 14, 16, 18, 20, 22 }));
            Assert.AreEqual(HandValue.Straight, Misc.GetHandValue(new int[] { 1,2,3,4,18 }));
            Assert.AreEqual(HandValue.StraightFlush, Misc.GetHandValue(new int[] { 8, 9, 10, 11, 12 }));
            Assert.AreEqual(HandValue.Straight, Misc.GetHandValue(new int[] { 12, 0, 1, 15, 3 }));
            Assert.AreEqual(HandValue.StraightFlush, Misc.GetHandValue(new int[] { 0, 1, 2, 3, 12 }));
            Assert.AreEqual(HandValue.StraightFlush, Misc.GetHandValue(new int[] { 0, 12, 2, 3, 1 }));
            Assert.AreEqual(HandValue.FullHouse, Misc.GetHandValue(new int[] { 0, 13, 26, 7, 20 }));
            Assert.AreEqual(HandValue.ThreeOfAKind, Misc.GetHandValue(new int[] { 0, 13, 26, 7, 21 }));
            Assert.AreEqual(HandValue.TwoPair, Misc.GetHandValue(new int[] { 0, 13, 14, 7, 20 }));
        }

        [Test]
        public void test_ValueHand_strings()
        {          
            Assert.AreEqual(HandValue.OnePair, Misc.GetHandValue(Misc.ParseHand("AH 3S 4C 5D AD")));
            Assert.AreEqual(HandValue.Straight, Misc.GetHandValue(Misc.ParseHand("3S 4C 5D 6H 7S")));
            Assert.AreEqual(HandValue.ThreeOfAKind, Misc.GetHandValue(Misc.ParseHand("3C 3S 3D 4H 5D")));
            Assert.AreEqual(HandValue.Flush, Misc.GetHandValue(Misc.ParseHand("5S AS JS 6S 4S")));
            Assert.AreEqual(HandValue.TwoPair, Misc.GetHandValue(Misc.ParseHand("3S 3D 4C 5H 4H")));
            Assert.AreEqual(HandValue.FullHouse, Misc.GetHandValue(Misc.ParseHand("2S 3C 2H 3D 2D")));
            Assert.AreEqual(HandValue.FourOfAKind, Misc.GetHandValue(Misc.ParseHand("2S 2H 2D 2C 3S")));
            Assert.AreEqual(HandValue.Straight, Misc.GetHandValue(Misc.ParseHand("AH 2H 3H 4H 5C")));
            Assert.AreEqual(HandValue.Straight, Misc.GetHandValue(Misc.ParseHand("TH JH QD KS AC")));
            Assert.AreEqual(HandValue.StraightFlush, Misc.GetHandValue(Misc.ParseHand("5H 6H 7H 8H 9H")));
            Assert.AreEqual(HandValue.HighCard, Misc.GetHandValue(Misc.ParseHand("5H 7D 6C 9S JH")));
        }

        [Test]
        public void test_CompareHands_strings()
        {
            Assert.AreEqual(HandComparison.Hand2, Misc.CompareHands("5H 7D 6C 9S JH", "3S 3D 4C 5H 4H"));
            Assert.AreEqual(HandComparison.Hand1, Misc.CompareHands("2S 2H 2D 2C 3S", "2S 3C 2H 3D 2D"));
            Assert.AreEqual(HandComparison.Equal, Misc.CompareHands("AS 2S 3S 4S 5C", "AC 2C 3C 4C 5S"));
            Assert.AreEqual(HandComparison.Hand2, Misc.CompareHands("AS 2S 3S 4S 5C", "2C 3C 4C 5S 6H"));
            Assert.AreEqual(HandComparison.Hand1, Misc.CompareHands("2C 3C 4C 5S 6H", "AS 2S 3D 4S 5C"));
            Assert.AreEqual(HandComparison.Equal, Misc.CompareHands("2C 5C 6C 7C 8C", "2S 5S 6S 7S 8S"));
            Assert.AreEqual(HandComparison.Hand1, Misc.CompareHands("3C 5C 6C 7C 8C", "2S 5S 6S 7S 8S"));
            Assert.AreEqual(HandComparison.Equal, Misc.CompareHands("2C 3S 5H 6D JS", "2D 3H 5C 6C JH"));
            Assert.AreEqual(HandComparison.Hand1, Misc.CompareHands("2C 4S 5H 6D JS", "2D 3H 5C 6C JH"));
            Assert.AreEqual(HandComparison.Hand2, Misc.CompareHands("2C 3S 5H 6D JS", "2D 3H 5C 7C JH"));
            Assert.AreEqual(HandComparison.Hand1, Misc.CompareHands("AS 2S 3S 4S 5S", "2D 3H 4C 5C 6C"));
            Assert.AreEqual(HandComparison.Hand2, Misc.CompareHands("AS 2S 3S 4S 5S", "2D 3D 4D 5D 6D"));
        }

        [Test]
        public void test_best_of_7()
        {
            Assert.AreEqual(HandValue.Flush, Misc.GetHandValue("5H 7H 6H 3D 3H 3S 2H"));
            Assert.AreEqual(HandValue.Flush, Misc.GetHandValue("5H 7H 6H 3H 3S 2H"));
            Assert.AreEqual(HandValue.Flush, Misc.GetHandValue("5H 7H 6H 3H 2H"));
        }

        [Test]
        public void test_findbest_three_and_two_pairs()
        {
            string s = "TS 5C 5S TH 5H 6S 6D";
            int[] best;
            HandValue hv = Misc.GetHandValue(Misc.ParseHand(s), out best);
            string s2 = Misc.HandString(best);
            Assert.AreEqual("TS TH 5S 5C 5H", s2);
        }

        [Test]
        public void test_findbest_six_card_flush()
        {
            string s = "KH AH 5H 7H JH 9H 4S";
            int[] best;
            HandValue hv = Misc.GetHandValue(Misc.ParseHand(s), out best);
            string s2 = Misc.HandString(best);
            Assert.AreEqual(s2, "AH KH JH 9H 7H");
        }

        [Test]
        public void test_sort()
        {
            int[] h = Misc.ParseHand("2C 4S 7D 3S 6C QS");
            Misc.SortByCardValueDescending(h);
            string s2 = Misc.HandString(h);
            Assert.AreEqual("QS 7D 6C 4S 3S 2C", s2);
        }

        [Test]
        public void test_flush_and_straight_but_not_straightflush()
        {
            Assert.AreEqual(HandValue.Flush, Misc.GetHandValue("2H 3C 4H 5H 6H JS 7H"));
        }

        [Test]
        public void test_two_threeofakinds_is_fullhouse()
        {
            Assert.AreEqual(HandValue.FullHouse, Misc.GetHandValue("5C 3S 8H 3D 3H 8D 8S"));
        }

        [Test]
        public void test_gameboy_holdem_bug()
        {
            Assert.AreEqual(HandComparison.Equal, Misc.CompareHands("2C 2S 9H TD QD 2H 3C", "2D 3S 2C 2S 9H TD QD"));
        }

        [Test]
        public void test_strings()
        {
            Deck d = new Deck();
            d.Shuffle(50);

            while (d.CardsRemaining >= 7)
            {
                int[] hand1 = d.GetHand(7);
                string s1 = Misc.HandString(hand1);
                int[] hand2 = Misc.ParseHand(s1);
                string s2 = Misc.HandString(hand2);
                Assert.AreEqual(HandComparison.Equal, Misc.CompareHands(s1, s2));
            }
        }
    }
}

#endif
