
/*
 * Copyright 2007 Eric Sink
 * 
 * You may use this code under the terms of any of the
 * following licenses, your choice:
 * 
 * 1)  The GNU General Public License, Version 2
 *      http://www.opensource.org/licenses/gpl-license.php
 * 
 * 2)  The Apache License, Version 2.0
 *      http://www.opensource.org/licenses/apache2.0.php
 * 
 * 3)  The MIT License
 *      http://www.opensource.org/licenses/mit-license.php
 *
 * I am publishing this code on my blog as sample
 * code.  I am not intending to maintain this as a 
 * regular ongoing open source project or
 * anything like that.  I'm not looking for contributors
 * or hosting on sourceforge or anything like that.
 * 
 * Nonetheless, I hate it when I see an article with
 * sample code and it's not clear if I am allowed to
 * use the code or not.  The ambiguity is annoying.
 * So I am making this code available under your 
 * choice of open source licenses as described above.  
 * Informally and in a nutshell, you can use this code 
 * for any purpose as long as I am not liable for anything 
 * that goes wrong.  For a more tedious and formal 
 * explanation, pick one of the licenses above and use it.
 * 
 */

using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace PokerLib
{
    // These are intentionally sorted in ascending order
    public enum HandValue
    {
        HighCard,
        OnePair,
        TwoPair,
        ThreeOfAKind,
        Straight,
        Flush,
        FullHouse,
        FourOfAKind,
        StraightFlush
    };

    public enum HandComparison
    {
        Hand1,
        Hand2,
        Equal
    };

    public class Misc
    {
        private static string card_value_chars = "23456789TJQKA";
        private static string card_suit_chars = "HCDS";
        public static string CardValueChar(int c)
        {
            Debug.Assert((c >= 0) && (c <= 12));
            return card_value_chars[c].ToString();
        }

        public static string CardSuitChar(int c)
        {
            Debug.Assert((c >= 0) && (c <= 3));
            return card_suit_chars[c].ToString();
        }

        public static string CardString(int c)
        {
            return string.Format("{0}{1}", CardValueChar(CardValue(c)), CardSuitChar(CardSuit(c)));
        }

        public static int ParseCard(string s)
        {
            return MakeCard(CardValueFromChar(s[0]), CardSuitFromChar(s[1]));
        }

        private static int CardSuitFromChar(char p)
        {
            return card_suit_chars.IndexOf(p);
        }

        private static int CardValueFromChar(char p)
        {
            return card_value_chars.IndexOf(p);
        }

        public static int[] ParseHand(string s)
        {
            string[] parts = s.Split(' ');
            int[] result = new int[parts.Length];
            for (int i = 0; i < parts.Length; i++)
            {
                result[i] = ParseCard(parts[i]);
            }
            return result;
        }

        public static int CardValue(int c)
        {
            return c % 13;
        }

        public static int CardSuit(int c)
        {
            return c / 13;
        }

        public static string HandString(int[] cards)
        {
            string s = "";
            for (int i = 0; i < cards.Length; i++)
            {
                s += CardString(cards[i]);
                if (i != cards.Length - 1)
                {
                    s += " ";
                }
            }
            return s;
        }

        public static int MakeCard(int val, int suit)
        {
            return suit * 13 + val;
        }

        public static HandValue GetHandValue(string s)
        {
            return GetHandValue(ParseHand(s));
        }

        public static HandValue GetHandValue(int[] cards)
        {
            int[] best5;
            HandValue hv = GetHandValue(cards, out best5);
            return hv;
        }

        private static int[] FindCount(Dictionary<int,int> vals, int c)
        {
            List<int> result = new List<int>();
            foreach (int cv in vals.Keys)
            {
                if (vals[cv] == c)
                {
                    result.Add(cv);
                }
            }
            int[] ca = ConvertToArray(result);
            return ca;
        }

        public static HandValue GetHandValue(int[] cards, out int[] best5)
        {
            Debug.Assert(cards.Length >= 5);
            Debug.Assert(cards.Length <= 7);

            bool bFlush = false;
            Dictionary<int, int> suits = new Dictionary<int, int>();
            for (int i = 0; i < cards.Length; i++)
            {
                int cs = CardSuit(cards[i]);
                if (!suits.ContainsKey(cs))
                {
                    suits[cs] = 1;
                }
                else
                {
                    suits[cs]++;
                }
            }

            int flush_suit = -1;
            foreach (int s in suits.Keys)
            {
                if (suits[s] >= 5)
                {
                    flush_suit = s;
                    bFlush = true;
                    break;
                }
            }

            if (bFlush)
            {
                int[] onesuit = new int[suits[flush_suit]];
                int c = 0;
                for (int i = 0; i < cards.Length; i++)
                {
                    if (CardSuit(cards[i]) == flush_suit)
                    {
                        onesuit[c++] = cards[i];
                    }
                }

                int[] best_straightflush;
                bool bStraightFlush = ValueHand_Straight(onesuit, out best_straightflush);
                if (bStraightFlush)
                {
                    best5 = best_straightflush;
                    return HandValue.StraightFlush;
                }
                else
                {
                    if (onesuit.Length == 5)
                    {
                        best5 = onesuit;
                    }
                    else
                    {
                        SortByCardValueDescending(onesuit);
                        best5 = Slice(onesuit, 0, 5);
                    }
                    return HandValue.Flush;
                }
            }

            int[] best_straight;
            bool bStraight = ValueHand_Straight(cards, out best_straight);

            if (bStraight)
            {
                best5 = best_straight;
                return HandValue.Straight;
            }

            Dictionary<int, int> vals = new Dictionary<int, int>();
            for (int i = 0; i < cards.Length; i++)
            {
                int cv = CardValue(cards[i]);
                if (!vals.ContainsKey(cv))
                {
                    vals[cv] = 1;
                }
                else
                {
                    vals[cv]++;
                }
            }

            Dictionary<int, int> counts = new Dictionary<int, int>();
            foreach (int k in vals.Keys)
            {
                int count = vals[k];
                if (!counts.ContainsKey(count))
                {
                    counts[count] = 1;
                }
                else
                {
                    counts[count]++;
                }
            }

            if (counts.ContainsKey(4))
            {
                int cv4 = FindCount(vals, 4)[0];

                List<int> result = new List<int>();
                CopyByCardValueUntil5(cards, result, cv4);
                Debug.Assert(result.Count == 4);

                int max = -1;
                for (int i = 0; i < cards.Length; i++)
                {
                    if (CardValue(cards[i]) != cv4)
                    {
                        if (max == -1)
                        {
                            max = cards[i];
                        }
                        else if (CardValue(cards[i]) > CardValue(max))
                        {
                            max = cards[i];
                        }
                    }
                }
                result.Add(max);
                best5 = ConvertToArray(result);

                return HandValue.FourOfAKind;
            }

            if (counts.ContainsKey(3))
            {
                int[] treys = FindCount(vals, 3);
                List<int> result = new List<int>();
                CopyByCardValueUntil5(cards, result, treys[0]);
                if (treys.Length > 1)
                {
                    Debug.Assert(treys.Length == 2);
                    CopyByCardValueUntil5(cards, result, treys[1]);
                    best5 = ConvertToArray(result);
                    return HandValue.FullHouse;
                }
                else if (counts.ContainsKey(2))
                {
                    int[] pairs = FindCount(vals, 2);
                    CopyByCardValueUntil5(cards, result, pairs[0]);
                    best5 = ConvertToArray(result);
                    return HandValue.FullHouse;
                }
                else
                {
                    int[] others = GetAllExceptCardValue(cards, treys[0]);
                    result.Add(others[0]);
                    result.Add(others[1]);
                    best5 = ConvertToArray(result);
                    return HandValue.ThreeOfAKind;
                }
            }

            if (counts.ContainsKey(2))
            {
                int[] pairs = FindCount(vals, 2);
                List<int> result = new List<int>();
                CopyByCardValueUntil5(cards, result, pairs[0]);
                if (pairs.Length == 1)
                {
                    int[] others = GetAllExceptCardValue(cards, pairs[0]);
                    result.Add(others[0]);
                    result.Add(others[1]);
                    result.Add(others[2]);
                    best5 = ConvertToArray(result);

                    return HandValue.OnePair;
                }
                else
                {
                    CopyByCardValueUntil5(cards, result, pairs[1]);
                    int[] others = GetAllExceptCardValue(cards, pairs[0], pairs[1]);
                    result.Add(others[0]);
                    best5 = ConvertToArray(result);
                    return HandValue.TwoPair;
                }
            }

            SortByCardValueDescending(cards);
            best5 = new int[5];
            for (int i = 0; i < 5; i++)
            {
                best5[i] = cards[i];
            }
            return HandValue.HighCard;
        }

        private class ComparisonCardValueDescending : Comparer<int>
        {
            public override int Compare(int x, int y)
            {
                if (CardValue(x) > CardValue(y))
                {
                    return -1;
                }
                else if (CardValue(x) < CardValue(y))
                {
                    return 1;
                }
                else
                {
                    if (x > y)
                    {
                        return -1;
                    }
                    else if (x < y)
                    {
                        return 1;
                    }
                    else
                    {
                        return 0;
                    }
                }
            }
        }

        public static void SortByCardValueDescending(int[] others)
        {
            Array.Sort(others, new ComparisonCardValueDescending());
        }

        private static int[] GetAllExceptCardValue(int[] cards, int p)
        {
            return GetAllExceptCardValue(cards, p, -1);
        }

        private static int[] GetAllExceptCardValue(int[] cards, int p, int q)
        {
            List<int> others = new List<int>();
            foreach (int x in cards)
            {
                if (
                    (CardValue(x) != p)
                    && (CardValue(x) != q)
                    )
                {
                    others.Add(x);
                }
            }
            return ConvertToArray(others);
        }

        private static int[] ConvertToArray(List<int> result)
        {
            int[] ca = new int[result.Count];
            result.CopyTo(ca);
            SortByCardValueDescending(ca);
            return ca;
        }

        private static void CopyByCardValueUntil5(int[] cards, List<int> result, int cv4)
        {
            foreach (int x in cards)
            {
                if (CardValue(x) == cv4)
                {
                    result.Add(x);
                    if (result.Count == 5)
                    {
                        return;
                    }
                }
            }
        }

        private static int[] Slice(int[] from, int begin, int len)
        {
            int[] result = new int[len];
            for (int i = 0; i < len; i++)
            {
                result[i] = from[begin + i];
            }
            return result;
        }

        private static bool ValueHand_Stripped_LowAceStraight(int[] cards)
        {
            return (
                (cards[0] == 12)
                && (cards[1] == 3)
                && (cards[2] == 2)
                && (cards[3] == 1)
                && (cards[4] == 0)
                );
        }

        private static bool ValueHand_Straight(int[] cards, out int[] best5)
        {
            int[] vals = StripDupsAndSuits(cards);
            if (vals.Length < 5)
            {
                best5 = null;
                return false;
            }

            int count = 1;
            for (int i = 1; i < vals.Length; i++)
            {
                if (vals[i] == vals[i - 1] - 1)
                {
                    count++;
                    if (count == 5)
                    {
                        best5 = ExtractStraight(cards, vals[i]);
                        return true;
                    }
                }
                else
                {
                    count = 1;
                }
            }

            if (
                (vals[vals.Length - 1] == 0)
                && (vals[vals.Length - 2] == 1)
                && (vals[vals.Length - 3] == 2)
                && (vals[vals.Length - 4] == 3)
                && (vals[0] == 12)
                )
            {
                best5 = new int[5];
                best5[0] = FindOneCardByValue(cards, 12);
                best5[1] = FindOneCardByValue(cards, 0);
                best5[2] = FindOneCardByValue(cards, 1);
                best5[3] = FindOneCardByValue(cards, 2);
                best5[4] = FindOneCardByValue(cards, 3);
                return true;
            }

            best5 = null;
            return false;
        }

        private static int[] ExtractStraight(int[] cards, int lowcard)
        {
            int[] best5 = new int[5];
            for (int i = 0; i < 5; i++)
            {
                best5[i] = FindOneCardByValue(cards, lowcard + i);
            }
            return best5;
        }

        private static int FindOneCardByValue(int[] cards, int p)
        {
            for (int i = 0; i < cards.Length; i++)
            {
                if (CardValue(cards[i]) == p)
                {
                    return cards[i];
                }
            }
            throw new Exception();
        }

        private static int[] StripDupsAndSuits(int[] cards)
        {
            Dictionary<int, int> v2 = new Dictionary<int, int>();
            foreach (int x in cards)
            {
                v2[CardValue(x)] = 1;
            }
            int[] v3 = new int[v2.Keys.Count];
            int c = 0;
            foreach (int x in v2.Keys)
            {
                v3[c++] = x;
            }
            SortByCardValueDescending(v3);
            return v3;
        }

        private static int[] StripSuits(int[] cards)
        {
            int[] result = new int[cards.Length];
            for (int i = 0; i < cards.Length; i++)
            {
                result[i] = CardValue(cards[i]);
            }
            SortByCardValueDescending(result);
            return result;
        }

        public static HandComparison CompareHands(string hand1, string hand2)
        {
            return CompareHands(ParseHand(hand1), ParseHand(hand2));
        }

        public static HandComparison CompareHands(int[] hand1, int[] hand2)
        {
            HandValue hv1 = GetHandValue(hand1);
            HandValue hv2 = GetHandValue(hand2);

            if (hv1 > hv2)
            {
                return HandComparison.Hand1;
            }
            if (hv2 > hv1)
            {
                return HandComparison.Hand2;
            }
            int[] vals1 = StripSuits(hand1);
            int[] vals2 = StripSuits(hand2);

            if (
                (hv1 == HandValue.Straight)
                || (hv1 == HandValue.StraightFlush)
                )
            {
                bool bLowAce1 = ValueHand_Stripped_LowAceStraight(vals1);
                bool bLowAce2 = ValueHand_Stripped_LowAceStraight(vals2);

                if (bLowAce1 && bLowAce2)
                {
                    return HandComparison.Equal;
                }

                if (bLowAce1)
                {
                    return HandComparison.Hand2;
                }

                if (bLowAce2)
                {
                    return HandComparison.Hand1;
                }
            }

            int i = 0;
            while (
                (i < vals1.Length)
                && (i < vals2.Length)
                )
            {
                int cv1 = vals1[i];
                int cv2 = vals2[i];

                if (cv1 > cv2)
                {
                    return HandComparison.Hand1;
                }
                if (cv2 > cv1)
                {
                    return HandComparison.Hand2;
                }

                i++;
            }

            return HandComparison.Equal;
        }

        private static bool FindCard(int[] hand, int c)
        {
            foreach (int x in hand)
            {
                if (x == c)
                {
                    return true;
                }
            }
            return false;
        }

        public static double CalcOdds(string me, string community)
        {
            return CalcOdds(ParseHand(me), ParseHand(community));
        }

        public static double CalcOdds(int[] me, int[] community)
        {
            int[] myHand = new int[me.Length + community.Length];
            me.CopyTo(myHand, 0);
            community.CopyTo(myHand, 2);

            int win = 0;
            int lose = 0;
            int tie = 0;
            for (int i = 0; i < 52; i++)
            {
                if (!FindCard(myHand, i))
                {
                    for (int j = i + 1; j < 52; j++)
                    {
                        if (!FindCard(myHand, j))
                        {
                            int[] thisHand = new int[community.Length + 2];
                            thisHand[0] = i;
                            thisHand[1] = j;
                            community.CopyTo(thisHand, 2);
                            switch (CompareHands(myHand, thisHand))
                            {
                                case HandComparison.Hand1: win++; break;
                                case HandComparison.Hand2: lose++; break;
                                case HandComparison.Equal: tie++; break;
                            }
                        }
                    }
                }
            }

            return (win + tie) / ((double)(win + lose + tie));
        }
    }

    public class Deck
    {
        private int[] cards = new int[52];
        private int nextCard = 0;

        public int CardsRemaining
        {
            get
            {
                return 52 - nextCard;
            }
        }

        public Deck()
        {
            for (int i = 0; i < 52; i++)
            {
                cards[i] = i;
            }
        }

        public void Shuffle(int numSwaps)
        {
            Random r = new Random();
            for (int i = 0; i < numSwaps; i++)
            {
                int ndx1 = r.Next(nextCard, 52);
                int ndx2 = r.Next(nextCard, 52);
                if (ndx1 != ndx2)
                {
                    int tmp = cards[ndx1];
                    cards[ndx1] = cards[ndx2];
                    cards[ndx2] = tmp;
                }
            }
        }

        public int GetNextCard()
        {
            return cards[nextCard++];
        }

        public int[] GetHand(int count)
        {
            int[] hand = new int[count];
            for (int i = 0; i < count; i++)
            {
                hand[i] = GetNextCard();
            }
            return hand;
        }
    }
}
