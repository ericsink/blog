
/*
 * Copyright 2007 Eric Sink
 * 
 * You may use this code under the terms of any of the
 * following licenses, your choice:
 * 
 * 1)  The GNU General Public License, Version 2
 *      http://www.opensource.org/licenses/gpl-license.php
 * 
 * 2)  The Apache License, Version 2.0
 *      http://www.opensource.org/licenses/apache2.0.php
 * 
 * 3)  The MIT License
 *      http://www.opensource.org/licenses/mit-license.php
 *
 * I am publishing this code on my blog as sample
 * code.  I am not intending to maintain this as a 
 * regular ongoing open source project or
 * anything like that.  I'm not looking for contributors
 * or hosting on sourceforge or anything like that.
 * 
 * Nonetheless, I hate it when I see an article with
 * sample code and it's not clear if I am allowed to
 * use the code or not.  The ambiguity is annoying.
 * So I am making this code available under your 
 * choice of open source licenses as described above.  
 * Informally and in a nutshell, you can use this code 
 * for any purpose as long as I am not liable for anything 
 * that goes wrong.  For a more tedious and formal 
 * explanation, pick one of the licenses above and use it.
 * 
 */

using System;
using System.Collections.Generic;
using System.Text;

using PokerLib;

namespace quickie
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DateTime.Now);
            Console.WriteLine();

            Dictionary<HandValue, int> results = new Dictionary<HandValue, int>();

            Deck d = new Deck();
            d.Shuffle(100);

            int count = 1000000;
            int dealsize = 7;

            for (int i = 0; i < count; i++)
            {
                if (d.CardsRemaining < dealsize)
                {
                    d = new Deck();
                    d.Shuffle(100);
                }

                int[] hand = d.GetHand(dealsize);
                HandValue hv = Misc.GetHandValue(hand);

                if (results.ContainsKey(hv))
                {
                    results[hv]++;
                }
                else
                {
                    results[hv] = 1;
                }
            }

            foreach (HandValue hv in Enum.GetValues(typeof(HandValue)))
            {
                if (results.ContainsKey(hv))
                {
                    Console.WriteLine(string.Format("{0}: {1}", hv, (results[hv] / (double)count)));
                }
                else
                {
                    Console.WriteLine(string.Format("{0}: {1}", hv, 0));
                }
            }

            // Compare the results to http://wizardofodds.com/poker

            Console.WriteLine();
            Console.WriteLine(DateTime.Now);
            Console.ReadKey();
        }
    }
}
