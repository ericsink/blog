
For overview information and copyright, read the comments
in multicore.cs.

